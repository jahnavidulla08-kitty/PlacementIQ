import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sqlalchemy.orm import Session
from sqlalchemy import create_engine

# Path configuration
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(CURRENT_DIR)
DATA_DIR = os.path.join(PROJECT_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "placement_data.db")
MODEL_PATH = os.path.join(CURRENT_DIR, "placement_model.pkl")
SCALER_PATH = os.path.join(CURRENT_DIR, "scaler.pkl")
METRICS_PATH = os.path.join(CURRENT_DIR, "model_metrics.json")

FEATURE_COLUMNS = [
    "cgpa",
    "tenth_percentage",
    "twelfth_percentage",
    "backlogs",
    "attendance",
    "coding_score",
    "aptitude_score",
    "communication_score",
    "projects",
    "internships",
    "certifications",
    "num_skills"
]

def load_data_from_db():
    engine = create_engine(f"sqlite:///{DB_PATH}")
    
    # Query students and count their skills
    query = """
    SELECT 
        s.student_id,
        s.cgpa,
        s.tenth_percentage,
        s.twelfth_percentage,
        s.backlogs,
        s.attendance,
        s.coding_score,
        s.aptitude_score,
        s.communication_score,
        s.projects,
        s.internships,
        s.certifications,
        s.placement_status,
        COUNT(sk.skill_id) as num_skills
    FROM students s
    LEFT JOIN student_skills sk ON s.student_id = sk.student_id
    GROUP BY s.student_id
    """
    df = pd.read_sql(query, engine)
    return df

def train_placement_model():
    print("=" * 60)
    print("PLACEMENTIQ — MACHINE LEARNING MODEL TRAINING PIPELINE")
    print("=" * 60)

    if not os.path.exists(DB_PATH):
        print(f"Error: Database not found at {DB_PATH}. Run seed script first.")
        return False

    df = load_data_from_db()
    print(f"Loaded {len(df)} student records from database.")
    print(f"Class distribution:\n{df['placement_status'].value_counts()}")

    X = df[FEATURE_COLUMNS]
    y = df["placement_status"]

    # Split dataset (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Feature Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train Random Forest Classifier
    rf_model = RandomForestClassifier(
        n_estimators=120,
        max_depth=9,
        min_samples_split=4,
        min_samples_leaf=2,
        random_state=42,
        class_weight="balanced"
    )
    rf_model.fit(X_train_scaled, y_train)

    # Evaluate model
    y_pred = rf_model.predict(X_test_scaled)
    y_prob = rf_model.predict_proba(X_test_scaled)[:, 1]

    acc = float(accuracy_score(y_test, y_pred))
    prec = float(precision_score(y_test, y_pred, zero_division=0))
    rec = float(recall_score(y_test, y_pred, zero_division=0))
    f1 = float(f1_score(y_test, y_pred, zero_division=0))
    cm = confusion_matrix(y_test, y_pred).tolist()

    # Feature importances
    importances = rf_model.feature_importances_
    feature_importance_list = [
        {"feature": feat, "importance": round(float(imp), 4)}
        for feat, imp in sorted(zip(FEATURE_COLUMNS, importances), key=lambda x: x[1], reverse=True)
    ]

    metrics = {
        "model_name": "Random Forest Classifier",
        "n_estimators": 120,
        "features": FEATURE_COLUMNS,
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_score": round(f1, 4),
        "confusion_matrix": cm,
        "feature_importances": feature_importance_list
    }

    # Save artifacts
    os.makedirs(CURRENT_DIR, exist_ok=True)
    joblib.dump(rf_model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)

    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nModel Training Successfully Completed!")
    print(f"Accuracy:  {acc * 100:.2f}%")
    print(f"Precision: {prec * 100:.2f}%")
    print(f"Recall:    {rec * 100:.2f}%")
    print(f"F1 Score:  {f1 * 100:.2f}%")
    print(f"\nTop 5 Influential Features:")
    for item in feature_importance_list[:5]:
        print(f" - {item['feature']}: {item['importance'] * 100:.2f}%")

    print(f"\nSaved model to:   {MODEL_PATH}")
    print(f"Saved scaler to:  {SCALER_PATH}")
    print(f"Saved metrics to: {METRICS_PATH}")
    print("=" * 60)
    return True

if __name__ == "__main__":
    train_placement_model()
